/* web_server/app.js 전체 코드 및 상세 설명 */

// ==========================================
// 1. 필요한 도구들 준비 (모듈 임포트)
// ==========================================
const express = require('express');        // 웹 서버를 구축하기 위한 핵심 프레임워크입니다.
const mysql = require('mysql2');          // MySQL 데이터베이스와 통신하기 위한 라이브러리입니다.
const cors = require('cors');              // 서로 다른 도메인 간의 데이터 요청을 허용해주는 보안 설정 도구입니다.
const bodyParser = require('body-parser'); // 사용자가 보낸 데이터(JSON 등)를 해석해서 컴퓨터가 읽기 쉽게 해줍니다.
const path = require('path');              // 파일이나 폴더의 경로를 안전하게 다루기 위한 도구입니다.
const { spawn } = require('child_process'); // Node.js에서 파이썬 같은 외부 프로그램을 실행시킬 때 사용하는 도구입니다.

const app = express();                     // express 도구를 실행하여 서버 객체를 생성합니다.
const PORT = 3000;                         // 이 서버가 사용할 통로 번호를 3000번으로 정합니다.

app.use(cors());                           // 모든 도메인에서의 접속을 허용합니다.
app.use(bodyParser.json());                // 본문에 담긴 JSON 데이터를 분석하도록 설정합니다.
// app.use(express.static(path.join(__dirname, 'public'))); // HTML, CSS 같은 정적 파일을 public 폴더에서 가져오도록 설정합니다.
app.use(express.static(__dirname)); // HTML, CSS 같은 정적 파일을 public 폴더에서 가져오도록 설정합니다.

// ==========================================
// 2. 경로 설정 (파이썬 파일 위치)
// ==========================================
// 랑랑의 컴퓨터에 설치된 파이썬 실행 파일의 절대 경로입니다.
const pythonEnvPath = 'C:/Users/smhrd/.conda/envs/mp_fix/python.exe'; 
// AI 로직이 들어있는 폴더와 실행할 메인 파이썬 파일의 경로를 조합합니다.
const aiServerDir = path.join(__dirname, '../ai_server');
const mainPyPath = path.join(aiServerDir, 'main.py');

// ==========================================
// 3. DB 연결 설정 (Connection Pool)
// ==========================================
const db = mysql.createPool({
    host: 'project-db-cgi.smhrd.com',      // 데이터베이스가 저장된 컴퓨터의 주소입니다.
    port: 3307,                            // 데이터베이스 접속 통로 번호입니다.
    user: '2nd_pjt',                       // 접속 아이디입니다.
    password: '1234',                      // 접속 비밀번호입니다.
    database: '2nd_pjt',                   // 사용할 데이터베이스 이름입니다.
    waitForConnections: true,              // 연결이 꽉 찼을 때 대기할지 여부입니다.
    connectionLimit: 10,                   // 한 번에 유지할 최대 연결 개수입니다.
    charset: 'utf8mb4'                     // 한글과 이모지 등을 지원하는 문자 집합입니다.
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "start", "index.html"));
});


// ==========================================
// 4. 회원가입 API (Signup)
// ==========================================
app.post('/signup', (req, res) => {
    // 사용자가 입력한 정보를 변수에 담습니다.
    const { login_id, user_pwd, user_name, email, gender, age } = req.body;
    // 데이터를 집어넣기 위한 SQL 문장입니다.
    const sql = `INSERT INTO user_info (login_id, user_pwd, user_name, email, gender, age) VALUES (?, ?, ?, ?, ?, ?)`;
    
    // DB에 쿼리를 실행합니다.
    db.query(sql, [login_id, user_pwd, user_name, email, gender, age], (err, result) => {
        if (err) {
            console.error("회원가입 에러:", err.message);
            return res.status(500).json({ status: 'error', msg: err.message });
        }
        res.json({ status: 'success' }); // 성공 시 성공 메시지를 보냅니다.
    });
});

// ==========================================
// 5. 로그인 API (Login)
// ==========================================
app.post('/login', (req, res) => {
    const { login_id, user_pwd } = req.body;
    // 아이디와 비밀번호가 일치하는 유저가 있는지 확인하는 SQL 문장입니다.
    const sql = 'SELECT user_no, user_name FROM user_info WHERE login_id = ? AND user_pwd = ?';
    
    db.query(sql, [login_id, user_pwd], (err, results) => {
        if (err) {
            console.error("로그인 에러:", err.message);
            return res.status(500).json({ status: 'error', msg: err.message });
        }
        
        if (results.length > 0) {
            // 결과가 있다면 로그인 성공! 유저 번호와 이름을 전달합니다.
            res.json({ status: 'success', user_no: results[0].user_no, name: results[0].user_name });
        } else {
            // 결과가 없다면 실패 메시지를 보냅니다.
            res.json({ status: 'fail', msg: '아이디 또는 비밀번호를 확인해주세요.' });
        }
    });
});

// ============================================================
// 6. 학습 시작 API (/start-learning) - 파이썬 AI 연동
// ============================================================

let currentPyProcess = null; // 현재 실행 중인 파이썬 프로세스를 저장할 변수입니다.

app.post('/start-learning', (req, res) => {
    const { user_no } = req.body; // 어떤 유저가 학습을 시작했는지 번호를 받습니다.

    console.log(`[Node] 학습 시작 요청 받음 (User: ${user_no})`);

    // spawn을 통해 파이썬 파일을 실행합니다. 인자로 유저 번호를 넘겨줍니다.
    const pyProc = spawn(pythonEnvPath, [mainPyPath, user_no], { 
        cwd: aiServerDir,
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' } // 한글 출력을 위해 인코딩을 설정합니다.
    });
    currentPyProcess = pyProc;

    let aiFeedbackText = ""; // 파이썬에서 보내줄 AI 멘트를 담을 변수입니다.
    
    // 파이썬의 표준 출력(print) 데이터를 실시간으로 감시합니다.
    pyProc.stdout.on('data', (data) => {
        const msg = data.toString().trim();
        console.log(`[Python]: ${msg}`); 

        // 만약 파이썬 출력 내용에 "AI_MSG:"라는 약속된 문구가 포함되어 있다면 데이터를 추출합니다.
        if (msg.includes("AI_MSG:")) {
            const parts = msg.split("AI_MSG:"); 
            if (parts.length > 1) {
                aiFeedbackText = parts[1].trim();
                console.log(`[AI 멘트 확보]: ${aiFeedbackText}`);
            }
        }
    });

    // 파이썬 실행 중 에러가 발생하면 출력합니다.
    pyProc.stderr.on('data', (data) => {
        console.error(`[Python Error]: ${data.toString().trim()}`);
    });

    // 파이썬 프로그램이 종료되었을 때 실행됩니다.
    pyProc.on('close', (code) => {
        console.log(`[Node] 분석 종료 (Exit Code: ${code})`);
        
        if (!aiFeedbackText) {
            aiFeedbackText = "분석이 완료되었습니다. (AI 응답 없음)";
        }

        // 최종적으로 AI의 멘트를 클라이언트(브라우저)에게 응답합니다.
        res.json({ 
            status: 'finished', 
            message: aiFeedbackText 
        });
    });
});

// ==========================================
// 7. 학습 중단 API (/stop-learning)
// ==========================================
app.post('/stop-learning', (req, res) => {
    if (currentPyProcess) {
        console.log('학습 종료 요청 받음');
        currentPyProcess.kill('SIGINT'); // 파이썬 프로세스에게 종료 신호를 보냅니다.
        currentPyProcess = null;
        res.json({ status: 'stopped' });
    } else {
        res.status(400).json({ error: '실행 중인 학습이 없습니다.' });
    }
});

// ==========================================
// 8. 서버 실행
// ==========================================
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});